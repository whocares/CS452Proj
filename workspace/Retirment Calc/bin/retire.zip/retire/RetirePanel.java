package retire;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class RetirePanel extends JPanel {

	private RetireModel rm;
	
	private JMenuItem clearItem, closeItem;
	private ButtonListener listener;
	private JButton calc;
	private JButton reset;
	
	private JPanel butPanel;
	private JPanel qaPanel;
	
	private JLabel sexQ;
	private JComboBox sexBox;
	private String[] sexString;
	
	private JLabel aTRQ;
	private String[] ageToRetire;
	private JComboBox aTRBox;
	
	private JLabel ageQ;
	private JLabel incomeQ;
	private JTextField ageF;
	private JTextField incomeF;
	
	private JLabel desiredSalary;
	private JTextField desiredSalaryField;
	
	private JLabel otherSalary;
	private JTextField otherSalaryField;
	
	private JLabel totalToSave;
	private JLabel totalTS;
	
	private JButton exit;
	
	public RetirePanel(JMenuItem clearItem, JMenuItem closeItem) {
		super();
		this.clearItem = clearItem;
		this.closeItem = closeItem;
		rm = new RetireModel();
		
		setLayout(new BorderLayout());
		
		qaPanel = new JPanel();
		qaPanel.setLayout(new GridLayout(8, 2, 20, 20));
		// rows, columns, horizontal gap, vertical gap
		add(qaPanel, BorderLayout.CENTER);
		
		setCombos();
		createButtons();
		setJLabels();
		setListen();
	}
	
	public void setJLabels() {
		ageQ = new JLabel("What is your age?");
		ageQ.setVisible(true);
		ageF = new JTextField();
		
		incomeQ = new JLabel("What is your current income?");
		incomeQ.setVisible(true);
		incomeF = new JTextField();
		
		desiredSalary = new JLabel("How much do you want to make?");
		desiredSalary.setVisible(true);
		desiredSalaryField = new JTextField();
		
		otherSalary = new JLabel("Do you have any other income?");
		otherSalary.setVisible(true);
		otherSalaryField = new JTextField();
		
		totalTS = new JLabel("How much you need to save: ");
		totalToSave = new JLabel("");
		
		sexQ = new JLabel("Are you male or female?");
		
		aTRQ = new JLabel("When do you want to retire?");
		
		qaPanel.add(sexQ);
		qaPanel.add(sexBox);
		qaPanel.add(ageQ);
		qaPanel.add(ageF);
		qaPanel.add(aTRQ);
		qaPanel.add(aTRBox);
		qaPanel.add(incomeQ);
		qaPanel.add(incomeF);
		qaPanel.add(otherSalary);
		qaPanel.add(otherSalaryField);
		qaPanel.add(desiredSalary);
		qaPanel.add(desiredSalaryField);
		qaPanel.add(totalTS);
		qaPanel.add(totalToSave);
		
		qaPanel.setBackground(Color.green);
	}
	
	public void setCombos() {
		sexString = new String[]{"Male", "Female"};
		sexBox = new JComboBox(sexString);
		
		ageToRetire = new String[]{" ", "55", "60", "65", "70"};
		aTRBox = new JComboBox(ageToRetire);
	}
	
	public void createButtons() {
		calc = new JButton("Show me the money!");
		reset = new JButton("Reset");
		exit = new JButton("Exit");
		
		butPanel = new JPanel();
		butPanel.setLayout(new FlowLayout());
		butPanel.add(calc);
		butPanel.add(reset);
		butPanel.add(exit);
		
		add(butPanel, BorderLayout.SOUTH);
	}
	
	private void setListen() {
		listener = new ButtonListener();
		
		clearItem.addActionListener(listener);
		closeItem.addActionListener(listener);
		reset.addActionListener(listener);
		calc.addActionListener(listener);
		exit.addActionListener(listener);
	}
	
	private void clearForm() {
		ageF.setText("");
		incomeF.setText("");
		otherSalaryField.setText("");
		desiredSalaryField.setText("");
		totalToSave.setText("");
	}
	
	private void calculate() {
		int i = sexBox.getSelectedIndex();
		if (i == 0)
			rm.setSex("male");
		else
			rm.setSex("female");
		
		System.out.println(""+ i);
		i = aTRBox.getSelectedIndex();
		if (i == 0) {
			System.out.println("OH NO!");
			System.exit(1);
		} else if (i == 1)
			rm.setAgeToRetire(55);
		else if (i == 2)
			rm.setAgeToRetire(60);
		else if (i == 3)
			rm.setAgeToRetire(65);
		else 
			rm.setAgeToRetire(70);
		
		System.out.println(""+ i);
		System.out.println(ageF.getText());
		System.out.println(incomeF.getText());
		System.out.println(desiredSalaryField.getText());
		System.out.println(otherSalaryField.getText());
		
		rm.setAge(Integer.parseInt(ageF.getText()));
		rm.setASalary(Integer.parseInt(incomeF.getText()));
		rm.setDSalary(Integer.parseInt(desiredSalaryField.getText()));
		rm.setOtherIncome(Integer.parseInt(otherSalaryField.getText()));
		totalToSave.setText("" + rm.calculate() + " every year");
	}
	
	private class ButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {

			JComponent comp = (JComponent) event.getSource();
		
			if (comp == clearItem || comp == reset) 
				clearForm();
			
			if (comp == closeItem || comp == exit) 
				System.exit(0);
			
			if (comp == calc)
				calculate();
		}
	}
}
