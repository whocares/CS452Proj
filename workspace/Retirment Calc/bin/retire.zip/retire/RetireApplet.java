package retire;

import java.applet.Applet;

import javax.swing.*;

public class RetireApplet {

	public static void main(String args[]) {
		JFrame frame = new JFrame("Retirement Calculator");
		JMenuBar menu = new JMenuBar();
		JMenu fileMenu = new JMenu("File");
		JMenuItem clearItem = new JMenuItem("Clear");
		JMenuItem closeItem = new JMenuItem("Close");
		
		frame.setJMenuBar(menu);
		menu.add(fileMenu);
		fileMenu.add(clearItem);
		fileMenu.add(closeItem);
		
		RetirePanel panel = new RetirePanel(clearItem, closeItem);
		
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		
		frame.setContentPane(panel);
		
		frame.setSize(450,450);
		frame.setVisible(true);
	}	
}
