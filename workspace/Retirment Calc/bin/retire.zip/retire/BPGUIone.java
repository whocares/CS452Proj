package retire;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;


/***********************************************************************
 * 
 * This class creates the GUI for the investment calculator.
 * 
 * 
 * 
 * 
 * @author Daniel Ayotte, Tyler Kelsey, Kang Mo
 * @version 1.0
 * 
 ***********************************************************************/
public class BPGUIone implements ActionListener{
	
	// Frames and Panels
	private JFrame f;
	private JPanel buttonsPanel;
	private JPanel questionsPanel;
	private JPanel headerPanel;
	
	
	// JTextField Inputs
	private JTextField percentIncomeBox;// percentage of annual income 
										//	wanted in retirement
	private JTextField pensionPayBox;	// Money from pension
	private JTextField partTimeIncBox;	// Money from partTime income
	private JTextField otherIncBox;		// Money from other income
	private JTextField addSavingsBox;	// Additional Savings needed
	
	// Labels for the inputs
	private JLabel retAnnIncLabel; 		// Annual income in retirement
	private JLabel percentIncomeLabel;	
	private JLabel pensionPayLabel;
	private JLabel partTimeIncLabel;
	private JLabel otherIncLabel;
	private JLabel addSavingsLabel;
	
	// Labels for combo boxes
	private JLabel expRetAgeLabel;
	private JLabel yearsTilLabel;
	
	// Labels not attached to inputs
	private JLabel extraIncomeLabel;
	
	
	
	// Combo Boxes for expected and year until retirement
	private String[] retireAges = {" ", "55", "60", "65", "70"};
	private JComboBox expRetAge;		// Expected Retirement Age
	private JLabel expReAge = new JLabel("When do you want to" +
			" retire?");
	 
	private String[] yearsTilList = {" ", "10", "15",
			"20", "25", "30", "35", "40"};
	private JComboBox yearsTil;			// Years until retirement
	 
	// Calculate and Reset buttons
	private JButton calc;
	private JButton reset;
	
	// header Image
	private ImageIcon header = new ImageIcon("header.jpeg");	
	private RetireModel m1;
	
	public BPGUIone(){
		
		// Frame
		f = new JFrame("Retirement Calculator");
		f.setLayout(new BorderLayout());
		
		setupPanels();
		
		f.add(headerPanel, BorderLayout.NORTH);
		f.add(questionsPanel, BorderLayout.CENTER);
		f.add(buttonsPanel, BorderLayout.SOUTH);
		
		f.setSize(800,600);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	private void setupPanels(){
		// Instantiating TextFields
		percentIncomeBox = new JTextField();
		pensionPayBox = new JTextField();
		partTimeIncBox = new JTextField();
		otherIncBox = new JTextField();
		addSavingsBox = new JTextField();
		
		
		// combo boxes
		expRetAge = new JComboBox(retireAges);
		yearsTil = new JComboBox(yearsTilList);
		
		
		// Labels
		percentIncomeLabel = new JLabel("How much annual income will you want in retirement?: ");
		pensionPayLabel = new JLabel("Traditional Employer Pension: ");
		partTimeIncLabel = new JLabel("Part-time Income: ");
		otherIncLabel = new JLabel("Other Sources: ");
		addSavingsLabel = new JLabel("Total additional savings needed at retirement");
		
		expRetAgeLabel = new JLabel("Choose the age you expect to retire");
		yearsTilLabel = new JLabel("Choose the number of years until your retirement");
		
		extraIncomeLabel = new JLabel("Input the income you expect to receive annual from: ");
		extraIncomeLabel.setSize(400, 30);
		
		// Buttons
		calc = new JButton("Calculate");
		reset = new JButton("Reset");
		
		calc.addActionListener(this);
		reset.addActionListener(this);
		
		headerPanel = new JPanel(new FlowLayout());
		headerPanel.add(new JLabel(header));
		
		GridLayout g = new GridLayout(11,2);
		g.setVgap(4);
		g.setHgap(4);
		
		questionsPanel = new JPanel(g);
		
		// Asking the first Question
		questionsPanel.add(percentIncomeLabel);
		questionsPanel.add(percentIncomeBox);
		
		// Empty Row
		questionsPanel.add(new JLabel(""));
		questionsPanel.add(new JLabel(""));
		
		// Subtracted Incomes
		questionsPanel.add(extraIncomeLabel);
		questionsPanel.add(new JLabel(""));
		
		
		pensionPayBox.setSize(30,5);
		questionsPanel.add(pensionPayLabel);
		questionsPanel.add(pensionPayBox);
		
		questionsPanel.add(otherIncLabel);
		questionsPanel.add(otherIncBox);
		
		// Empty Row
		questionsPanel.add(new JLabel(""));
		questionsPanel.add(new JLabel(""));
		
		// Expect retirement age
		questionsPanel.add(expRetAgeLabel);
		questionsPanel.add(expRetAge);
		
		// Empty Row
		questionsPanel.add(new JLabel(""));
		questionsPanel.add(new JLabel(""));
		
		//Years until retirement
		questionsPanel.add(yearsTilLabel);
		questionsPanel.add(yearsTil);
		
		// Empty Row
		questionsPanel.add(new JLabel(""));
		questionsPanel.add(new JLabel(""));
		
		// other incomes
		questionsPanel.add(otherIncLabel);
		questionsPanel.add(otherIncBox);		
		
		buttonsPanel = new JPanel(new GridLayout(1,5));
		
		buttonsPanel.add(new JLabel("     "));
		buttonsPanel.add(new JLabel("     "));
		buttonsPanel.add(new JLabel("     "));
		buttonsPanel.add(reset);
		buttonsPanel.add(calc);
	
	}
	
	private void reset(){
		percentIncomeBox.setText("");
		pensionPayBox.setText("");
		partTimeIncBox.setText("");
		otherIncBox.setText("");
		addSavingsBox.setText("");
		expRetAge.setSelectedIndex(0);
		yearsTil.setSelectedIndex(0);
		
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == calc){
			// Call calculate method
			// m.calculate();
		}
		
		else if(e.getSource() == reset){
			reset();
		}
		
	}
	
	

	public static void main(String[] args){
		new BPGUIone();
	}
	
}
